try {
  importScripts('setup.js');
} catch (error) {
  console.log(error);
}

try {
  importScripts('requestinterceptor.js');
} catch (error) {
  console.log(error);
}

// Load each part like this 
try {
  importScripts('rightClick.js');
} catch (error) {
  console.log(error);
}

// Load each part like this 
try {
  importScripts('siteQualityMapping.js');
} catch (error) {
  console.log(error);
}